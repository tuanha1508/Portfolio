This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-pixel/


Super Pixel: Where Fancy, Bold, and Unique Pixels Collide
Super Pixel isn't your average pixel font. It's a bold statement for those who crave uniqueness. It's where playful fancy meets uncompromising strength, all rendered in the charming grit of pixels.